///////////////////////////////////////////////////////////
//
// Υλοποίηση του ADT Vector μέσω Dynamic Array.
//
///////////////////////////////////////////////////////////

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "ADTVector.h"


// Το αρχικό μέγεθος που δεσμεύουμε
#define VECTOR_MIN_CAPACITY 10

// Ένα VectorNode είναι pointer σε αυτό το struct. (το struct περιέχει μόνο ένα στοιχείο, οπότε θα μπροούσαμε και να το αποφύγουμε, αλλά κάνει τον κώδικα απλούστερο)
struct vector_node {
	Pointer value;				// Η τιμή του κόμβου.
};

// Ενα Vector είναι pointer σε αυτό το struct
struct vector {
	VectorNode array;			// Τα δεδομένα, πίνακας από struct vector_node
	int size;					// Πόσα στοιχεία έχουμε προσθέσει
	int capacity;				// Πόσο χώρο έχουμε δεσμεύσει (το μέγεθος του array). Πάντα capacity >= size, αλλά μπορεί να έχουμε
	DestroyFunc destroy_value;	// Συνάρτηση που καταστρέφει ένα στοιχείο του vector.
	int steps;
};


Vector vector_create(int size, DestroyFunc destroy_value) {
	// Δημιουργία του struct
	Vector vec = malloc(sizeof(*vec));

	vec->size = size;
	vec->destroy_value = destroy_value;

	// Δέσμευση μνήμης για τον πίνακα. Αρχικά το vector περιέχει size
	// μη-αρχικοποιημένα στοιχεία, αλλά εμείς δεσμεύουμε xώρο για τουλάχιστον
	// VECTOR_MIN_CAPACITY για να αποφύγουμε τα πολλαπλά resizes.
	//
	vec->capacity = size < VECTOR_MIN_CAPACITY ? VECTOR_MIN_CAPACITY : size;
	vec->array = calloc(vec->capacity, sizeof(*vec->array));		// αρχικοποίηση σε 0 (NULL)
	vec->steps = 1;

	return vec;
}

int vector_size(Vector vec) {
	vec->steps=1;
	return vec->size;
}

Pointer vector_get_at(Vector vec, int pos) {
	assert(pos >= 0 && pos < vec->size);	// LCOV_EXCL_LINE (αγνοούμε το branch από τα coverage reports, είναι δύσκολο να τεστάρουμε το false γιατί θα κρασάρει το test)
	vec->steps=1;
	return vec->array[pos].value;
}

void vector_set_at(Vector vec, int pos, Pointer value) {
	assert(pos >= 0 && pos < vec->size);	// LCOV_EXCL_LINE

	// Αν υπάρχει συνάρτηση destroy_value, την καλούμε για το στοιχείο που αντικαθίσταται
	if (value != vec->array[pos].value && vec->destroy_value != NULL)
		vec->destroy_value(vec->array[pos].value);

	vec->array[pos].value = value;
	vec->steps=1;
}

void vector_insert_last(Vector vec, Pointer value) {
	vec->steps = 1;
	// Μεγαλώνουμε τον πίνακα (αν χρειαστεί), ώστε να χωράει τουλάχιστον size στοιχεία
	// Διπλασιάζουμε κάθε φορά το capacity (σημαντικό για την πολυπλοκότητα!)
	if (vec->capacity == vec->size) {
		// Προσοχή: δεν πρέπει να κάνουμε free τον παλιό pointer, το κάνει η realloc
		vec->capacity *= 2;
		vec->array = realloc(vec->array, vec->capacity * sizeof(*vec->array));
		vec->steps += vector_size(vec); //λογω των copy που κανει η realloc
	}

	// Μεγαλώνουμε τον πίνακα και προσθέτουμε το στοιχείο
	vec->array[vec->size].value = value;
	vec->size++;
	}

void vector_remove_last(Vector vec) {
	assert(vec->size != 0);		// LCOV_EXCL_LINE

	// Αν υπάρχει συνάρτηση destroy_value, την καλούμε για το στοιχείο που αφαιρείται
	if (vec->destroy_value != NULL)
		vec->destroy_value(vec->array[vec->size - 1].value);

	// Αφαιρούμε στοιχείο οπότε ο πίνακας μικραίνει
	vec->size--;
	vec->steps = 1;
	// Μικραίνουμε τον πίνακα αν χρειαστεί, ώστε να μην υπάρχει υπερβολική σπατάλη χώρου.
	// Για την πολυπλοκότητα είναι σημαντικό να μειώνουμε το μέγεθος στο μισό, και μόνο
	// αν το capacity είναι τετραπλάσιο του size (δηλαδή το 75% του πίνακα είναι άδειος).
	//
	if (vec->capacity > vec->size * 4 && vec->capacity > 2*VECTOR_MIN_CAPACITY) {
		vec->capacity /= 2;
		vec->array = realloc(vec->array, vec->capacity * sizeof(*vec->array));
		vec->steps+=vector_size(vec);
	}
}

Pointer vector_find(Vector vec, Pointer value, CompareFunc compare) {
	// Διάσχιση του vector
	for (int i = 0; i < vec->size; i++)
		if (compare(vec->array[i].value, value) == 0){
			return vec->array[i].value;		// βρέθηκε
			vec->steps = i;
		}
	vec->steps = vector_size(vec);
	return NULL;				// δεν υπάρχει
}

DestroyFunc vector_set_destroy_value(Vector vec, DestroyFunc destroy_value) {
	DestroyFunc old = vec->destroy_value;
	vec->destroy_value = destroy_value;
	vec->steps = 1;
	return old;
}

void vector_destroy(Vector vec) {
	// Αν υπάρχει συνάρτηση destroy_value, την καλούμε για όλα τα στοιχεία
	if (vec->destroy_value != NULL)
		for (int i = 0; i < vec->size; i++)
			vec->destroy_value(vec->array[i].value);

	// Πρέπει να κάνουμε free τόσο τον πίνακα όσο και το struct!
	free(vec->array);
	free(vec);			// τελευταίο το vec!
}


// Συναρτήσεις για διάσχιση μέσω node /////////////////////////////////////////////////////

VectorNode vector_first(Vector vec) {
	vec->steps=1;
	if (vec->size == 0)
		return VECTOR_BOF;
	else	
		return &vec->array[0];
}

VectorNode vector_last(Vector vec) {
	vec->steps=1;
	if (vec->size == 0)
		return VECTOR_EOF;
	else
		return &vec->array[vec->size-1];
}

VectorNode vector_next(Vector vec, VectorNode node) {
	vec->steps=1;
	if (node == &vec->array[vec->size-1])
		return VECTOR_EOF;
	else
		return node + 1;
}

VectorNode vector_previous(Vector vec, VectorNode node) {
	vec->steps=1;
	if (node == &vec->array[0])
		return VECTOR_EOF;
	else
		return node - 1;
}

Pointer vector_node_value(Vector vec, VectorNode node) {
	vec->steps=1;
	return node->value;
}

VectorNode vector_find_node(Vector vec, Pointer value, CompareFunc compare) {
	// Διάσχιση του vector
	for (int i = 0; i < vec->size; i++)
		if (compare(vec->array[i].value, value) == 0){
			vec->steps=i;
			return &vec->array[i];		// βρέθηκε
		}
	vec->steps = vector_size(vec);
	return VECTOR_EOF;				// δεν υπάρχει
}

int vector_steps(Vector vector){
	return vector->steps;
}